package model;

public class Word {
    public String f_word;
    public String m_word;
    public int itemId;

    public Word(String wordString) {

    }

    public String getF_word() {
        return f_word;
    }

    public void setF_word(String f_word) {
        this.f_word = f_word;
    }

    public String getM_word() {
        return m_word;
    }

    public void setM_word(String m_word) {
        this.m_word = m_word;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

}
